<?php $__env->startSection('content'); ?>
    <h1>Add Deal</h1>
    <?php echo Form::open(['action' => 'DealsController@store', 'method' => 'POST']); ?>

        <div class="form-group">
            <?php echo e(Form::label('deal_name', 'Name')); ?>

            <?php echo e(Form::text('deal_name', '', ['class' => 'form-control', 'placeholder' => 'Name'])); ?>

        </div>    
        <div class="form-group">
            <?php echo e(Form::label('deal_description', 'Description')); ?>

            <?php echo e(Form::textarea('deal_description', '', ['id' => 'article-ckeditor', 'class' => 'form-control', 'placeholder' => 'Description'])); ?>

        </div> 
        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

        <a href="/deals" class="btn btn-primary">Cancel</a>
    <?php echo Form::close(); ?>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>