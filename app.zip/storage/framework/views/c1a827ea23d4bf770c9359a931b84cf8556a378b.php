<?php $__env->startSection('content'); ?>
    <h1>Deals</h1>
    <?php if(count($deals) > 0): ?>
        <?php $__currentLoopData = $deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well">
                <h3><a href="/deals/<?php echo e($deal->id); ?>"><?php echo e($deal->deal_name); ?></a></h3>
                <small>Added on <?php echo e($deal->created_at); ?></small>
            </div>     
            <br />  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br />
        <?php echo e($deals->links()); ?>    
    <?php else: ?>
        <p>No deals found.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>