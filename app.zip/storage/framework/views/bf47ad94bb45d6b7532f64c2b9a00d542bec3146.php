<?php $__env->startSection('content'); ?>
    <a href="/deals" class="btn btn-default">Go Back</a>
    <h1><?php echo e($deal->deal_name); ?></h1>
    <small>Added on <?php echo e($deal->created_at); ?></small>
    <br /><br />
    <div>
        <?php echo $deal->deal_description; ?>

    </div>
    
    <br />
    <a href="/deals/<?php echo e($deal->id); ?>/edit" class="btn btn-primary">Edit</a>    
    
    <?php echo Form::open(['action' => ['DealsController@destroy', $deal->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

        <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>