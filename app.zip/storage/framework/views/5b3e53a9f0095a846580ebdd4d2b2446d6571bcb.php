<?php $__env->startSection('content'); ?>
    <h1>Agencies</h1>
    <?php if(count($agencies) > 0): ?>
        <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well">
                <h3><a href="/agencies/<?php echo e($agency->id); ?>"><?php echo e($agency->agency_name); ?></a></h3>
                <small>Added on <?php echo e($agency->created_at); ?></small>
            </div>     
            <br />  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br />
        <?php echo e($agencies->links()); ?>    
    <?php else: ?>
        <p>No travel agencies found.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>