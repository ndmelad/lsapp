@extends('layouts.app')

@section('content')
    <h1>Add Deal</h1>
    {!! Form::open(['action' => 'DealsController@store', 'method' => 'POST']) !!}
        <div class="form-group">
            {{Form::label('deal_name', 'Name')}}
            {{Form::text('deal_name', '', ['class' => 'form-control', 'placeholder' => 'Name'])}}
        </div>    
        <div class="form-group">
            {{Form::label('deal_description', 'Description')}}
            {{Form::textarea('deal_description', '', ['id' => 'article-ckeditor', 'class' => 'form-control', 'placeholder' => 'Description'])}}
        </div> 
        {{Form::submit('Submit', ['class' => 'btn btn-primary'])}}
        <a href="/deals" class="btn btn-primary">Cancel</a>
    {!! Form::close() !!}
    
@endsection
