<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Deal;

class DealsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $deals = Deal::paginate(10);
        return view('deals.index')->with('deals', $deals);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('deals.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'deal_name' => 'required',
            'deal_description' => 'required'
        ]);

        //Add Deal
        $deal = new Deal;
        $deal->deal_name = $request->input('deal_name');
        $deal->deal_description = $request->input('deal_description');
        $deal->save();

        return redirect('/deals')->with('success', 'Deal Added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $deal = Deal::find($id);
        return view('deals.show')->with('deal', $deal);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $deal = Deal::find($id);
        return view('deals.edit')->with('deal', $deal);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'deal_name' => 'required',
            'deal_description' => 'required'
        ]);

        //Add Deal
        $deal = Deal::find($id);
        $deal->deal_name = $request->input('deal_name');
        $deal->deal_description = $request->input('deal_description');
        $deal->save();

        return redirect('/deals')->with('success', 'Deal Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deal = Deal::find($id);
        $deal->delete();
        return redirect('/deals')->with('success', 'Deal Removed');
    }
}
